export { AppComponent } from './app/app';
