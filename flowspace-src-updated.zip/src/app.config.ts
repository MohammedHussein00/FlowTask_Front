export { appConfig } from './app/app.config';
