import { ApplicationConfig, ErrorHandler, Injectable, inject } from '@angular/core';
import { HttpClient, provideHttpClient } from '@angular/common/http';
import { provideRouter } from '@angular/router';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import { APOLLO_OPTIONS, Apollo, HttpLink } from 'apollo-angular';
import { InMemoryCache } from '@apollo/client/core';
import { setContext } from '@apollo/client/link/context';
import { provideTransloco, TranslocoLoader, Translation } from '@ngneat/transloco';
import { routes } from './app.routes';
import { AuthSessionStore } from './core/auth/auth-session.store';
import { GlobalErrorHandler } from './core/errors/global-error.handler';
import { LocaleService } from './core/i18n/locale.service';
import { environment } from '../environments/environment';

@Injectable({ providedIn: 'root' })
export class GlobalTranslocoLoader implements TranslocoLoader {
  private readonly http = inject(HttpClient);

  getTranslation(lang: string) {
    return this.http.get<Translation>(`/assets/i18n/${lang}.json`);
  }
}

export const appConfig: ApplicationConfig = {
  providers: [
    provideRouter(routes),
    provideHttpClient(),
    provideAnimationsAsync(),
    LocaleService,
    AuthSessionStore,
    { provide: ErrorHandler, useClass: GlobalErrorHandler },
    Apollo,
    {
      provide: APOLLO_OPTIONS,
      useFactory: (httpLink: HttpLink, session: AuthSessionStore) => {
        const authLink = setContext((_, context) => {
          const token = session.accessToken;
          const headers = context['headers'] ?? {};
          return {
            headers: token
              ? { ...headers, Authorization: `Bearer ${token}` }
              : headers,
          };
        });

        return {
          cache: new InMemoryCache(),
          link: authLink.concat(httpLink.create({
            uri: environment.graphqlUrl,
            withCredentials: true,
          })),
          defaultOptions: {
            watchQuery: { errorPolicy: 'none' },
            query: { errorPolicy: 'none' },
            mutate: { errorPolicy: 'none' },
          },
        };
      },
      deps: [HttpLink, AuthSessionStore],
    },
    provideTransloco({
      config: {
        availableLangs: ['en', 'ar', 'fr'],
        defaultLang: 'en',
        reRenderOnLangChange: true,
        prodMode: environment.production,
      },
      loader: GlobalTranslocoLoader,
    }),
  ],
};
