import { Injectable, computed, signal } from '@angular/core';

export interface AuthUser {
  userId: number;
  email: string;
  fullName: string;
}

export interface AuthSession {
  user: AuthUser;
  accessToken: string;
  expiresAt: string;
}

@Injectable({ providedIn: 'root' })
export class AuthSessionStore {
  private readonly session = signal<AuthSession | null>(null);
  readonly current = this.session.asReadonly();
  readonly isAuthenticated = computed(() => this.session() !== null);

  setSession(session: AuthSession): void {
    this.session.set(session);
  }

  clear(): void {
    this.session.set(null);
  }

  get accessToken(): string | null {
    return this.session()?.accessToken ?? null;
  }
}
