/**
 * ClickUp reference fidelity: "All settings" overlay panel.
 * Renders a two-column settings page (left nav + right content) that slides
 * over the contextual sidebar without hiding the global rail.
 *
 * Usage: navigate to /settings  — the ShellComponent detects this route and
 * renders <app-all-settings> in an overlay slot positioned on top of the
 * contextual sidebar area.
 */
import {
  ChangeDetectionStrategy, Component, output, signal,
} from '@angular/core';
import { LucideAngularModule, X, ChevronRight, User, Bell, Briefcase, MessageSquare, Users, Link, LogOut, Settings, Shield, Trash2, Zap, Globe, Clock, ToggleLeft, Tag, Layout, Cpu, Smile, Box, ClipboardList, Key, BarChart2, Mail } from 'lucide-angular';

type SettingsSection =
  | 'profile' | 'notifications' | 'workspaces' | 'chat' | 'referrals'
  | 'general' | 'people' | 'teams' | 'upgrade' | 'billing' | 'ai-usage'
  | 'security' | 'audit-logs' | 'trash'
  | 'custom-fields' | 'tag-manager' | 'template-center'
  | 'automations' | 'ai-notetaker' | 'emojis' | 'spaces'
  | 'task-types' | 'work-schedule'
  | 'app-center' | 'imports-exports' | 'clickup-api' | 'email-integration'
  | 'preferences';

interface NavItem {
  id: SettingsSection;
  label: string;
  icon: unknown;
}

interface NavGroup {
  heading: string | null;
  items: NavItem[];
}

@Component({
  selector: 'app-all-settings',
  standalone: true,
  imports: [LucideAngularModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
<div class="settings-overlay" (click)="onBackdropClick($event)">
  <div class="settings-panel" (click)="$event.stopPropagation()">

    <!-- Left settings nav -->
    <nav class="settings-nav" aria-label="Settings navigation">
      <div class="settings-nav__header">
        <span class="settings-nav__title">All settings</span>
        <button class="settings-nav__close" type="button" aria-label="Close settings" (click)="close.emit()">
          <lucide-icon [img]="X" size="16" />
        </button>
      </div>

      @for (group of navGroups; track group.heading) {
        @if (group.heading) {
          <p class="settings-nav__group-label">{{ group.heading }}</p>
        }
        @for (item of group.items; track item.id) {
          <button
            class="settings-nav__item"
            [class.settings-nav__item--active]="activeSection() === item.id"
            type="button"
            (click)="activeSection.set(item.id)"
          >
            <lucide-icon [img]="item.icon" size="15" />
            <span>{{ item.label }}</span>
          </button>
        }
      }

      <div class="settings-nav__footer">
        <button class="settings-nav__item settings-nav__item--danger" type="button">
          <lucide-icon [img]="LogOut" size="15" /><span>Log out</span>
        </button>
      </div>
    </nav>

    <!-- Right settings content -->
    <div class="settings-content">
      <div class="settings-content__inner">

        @switch (activeSection()) {

          <!-- ─── MY SETTINGS › PROFILE ─────────────────────────── -->
          @case ('profile') {
            <h1 class="settings-h1">My Settings</h1>
            <section class="settings-section">
              <div class="settings-section__label">
                <h2>Profile</h2>
                <p>Your personal information and account security settings.</p>
              </div>
              <div class="settings-section__fields">
                <div class="avatar-row">
                  <div class="avatar-circle">MM</div>
                  <div>
                    <p class="avatar-name">Muhammed Hussein Sophy Mustafa</p>
                    <button class="link-btn" type="button">Change avatar</button>
                  </div>
                </div>
                <label class="field-label">Full Name
                  <div class="field-input-wrap"><lucide-icon [img]="User" size="14" /><input class="field-input" type="text" value="Muhammed Hussein Sophy Mustafa" /></div>
                </label>
                <label class="field-label">Email
                  <div class="field-input-wrap"><lucide-icon [img]="Mail" size="14" /><input class="field-input" type="email" value="mh2156@fayoum.edu.eg" /></div>
                </label>
                <label class="field-label">Password
                  <div class="field-input-wrap"><lucide-icon [img]="Key" size="14" /><input class="field-input" type="password" placeholder="Enter New Password" /></div>
                </label>
              </div>
            </section>

            <section class="settings-section">
              <div class="settings-section__label">
                <h2>Two-factor authentication (2FA)</h2>
                <p>Keep your account secure by enabling 2FA via SMS or using a temporary one-time passcode (TOTP) from an authenticator app.</p>
              </div>
              <div class="settings-section__fields">
                <div class="toggle-row">
                  <div class="toggle-info">
                    <strong>Text Message (SMS)</strong>
                    <span>Receive a one-time passcode via SMS each time you log in.</span>
                    <span class="badge badge--business">Business</span>
                  </div>
                  <button class="toggle" type="button" aria-pressed="false"></button>
                </div>
                <div class="toggle-row">
                  <div class="toggle-info">
                    <strong>Authenticator App (TOTP)</strong>
                    <span>Use an app to receive a temporary one-time passcode each time you log in.</span>
                  </div>
                  <button class="toggle" type="button" aria-pressed="false"></button>
                </div>
              </div>
            </section>

            <section class="settings-section">
              <div class="settings-section__label">
                <h2>Theme color</h2>
                <p>Choose a preferred theme for the app.</p>
              </div>
              <div class="settings-section__fields">
                <div class="color-swatches">
                  @for (swatch of themeColors; track swatch.value) {
                    <button class="swatch" [style.background]="swatch.value" [class.swatch--active]="activeTheme() === swatch.value" type="button" (click)="activeTheme.set(swatch.value)" [attr.aria-label]="swatch.label"></button>
                  }
                </div>
                <div class="appearance-row">
                  <button class="appearance-btn" [class.appearance-btn--active]="activeAppearance() === 'light'" type="button" (click)="activeAppearance.set('light')">
                    <div class="appearance-preview appearance-preview--light"><span></span><span></span></div>
                    <small>Light</small>
                  </button>
                  <button class="appearance-btn appearance-btn--active" [class.appearance-btn--active]="activeAppearance() === 'dark'" type="button" (click)="activeAppearance.set('dark')">
                    <div class="appearance-preview appearance-preview--dark"><span></span><span></span></div>
                    <small>Dark</small>
                  </button>
                  <button class="appearance-btn" [class.appearance-btn--active]="activeAppearance() === 'auto'" type="button" (click)="activeAppearance.set('auto')">
                    <div class="appearance-preview appearance-preview--auto"><span></span><span></span></div>
                    <small>Auto</small>
                  </button>
                </div>
              </div>
            </section>

            <section class="settings-section">
              <div class="settings-section__label">
                <h2>Language &amp; Region</h2>
                <p>Customize your language and region.</p>
              </div>
              <div class="settings-section__fields">
                <label class="field-label">Language
                  <div class="field-select-wrap"><lucide-icon [img]="Globe" size="14" /><select class="field-select"><option>English</option><option>العربية</option><option>Français</option></select></div>
                </label>
                <label class="field-label">Timezone
                  <div class="field-select-wrap"><lucide-icon [img]="Clock" size="14" /><select class="field-select"><option>Africa/Cairo</option></select></div>
                </label>
                <label class="checkbox-label"><input type="checkbox" checked /> Notify me of Timezone changes</label>
              </div>
            </section>
          }

          <!-- ─── MY SETTINGS › PREFERENCES ─────────────────────── -->
          @case ('preferences') {
            <h1 class="settings-h1">Preferences</h1>

            <section class="settings-section">
              <div class="settings-section__label">
                <h2>Time &amp; Date format</h2>
                <p>Select the way times &amp; dates are displayed.</p>
              </div>
              <div class="settings-section__fields">
                <fieldset class="radio-group">
                  <legend>Start of the calendar week</legend>
                  <label><input type="radio" name="week-start" value="sunday" checked /> Sunday</label>
                  <label><input type="radio" name="week-start" value="monday" /> Monday</label>
                </fieldset>
                <fieldset class="radio-group">
                  <legend>Time format</legend>
                  <label><input type="radio" name="time-fmt" value="24" /> 24 hour</label>
                  <label><input type="radio" name="time-fmt" value="12" checked /> 12 hour</label>
                </fieldset>
                <fieldset class="radio-group">
                  <legend>Date format</legend>
                  <label><input type="radio" name="date-fmt" value="mdy" checked /> mm/dd/yyyy</label>
                  <label><input type="radio" name="date-fmt" value="dmy" /> dd/mm/yyyy</label>
                  <label><input type="radio" name="date-fmt" value="ymd" /> yyyy/mm/dd</label>
                </fieldset>
              </div>
            </section>

            <section class="settings-section">
              <div class="settings-section__label">
                <h2>Preferences</h2>
                <p>Manage your in-app preferences.</p>
              </div>
              <div class="settings-section__fields">
                @for (pref of appPreferences; track pref.key) {
                  <div class="toggle-row">
                    <div class="toggle-info">
                      <strong>{{ pref.label }}</strong>
                      <span>{{ pref.description }}</span>
                    </div>
                    <button class="toggle" [class.toggle--on]="pref.on" type="button" [attr.aria-pressed]="pref.on" (click)="pref.on = !pref.on"></button>
                  </div>
                }
              </div>
            </section>

            <section class="settings-section">
              <div class="settings-section__label">
                <h2>Link &amp; Mention Display</h2>
                <p>Manage how links are pasted and displayed across ClickUp.</p>
              </div>
              <div class="settings-section__fields">
                <div class="toggle-row">
                  <div class="toggle-info">
                    <strong>External Link Previews</strong>
                    <span>Paste a link and we'll turn it into a preview card. Your choice is remembered per site.</span>
                  </div>
                  <button class="toggle toggle--on" type="button" aria-pressed="true"></button>
                </div>
                <div class="task-mention-group">
                  <strong class="task-mention-title">Task Mentions</strong>
                  <p>Choose what shows alongside the task name when you mention a task.</p>
                  <div class="toggle-row"><div class="toggle-info"><strong>Show Status</strong></div><button class="toggle toggle--on" type="button" aria-pressed="true"></button></div>
                  <div class="toggle-row"><div class="toggle-info"><strong>Show Assignee</strong></div><button class="toggle toggle--on" type="button" aria-pressed="true"></button></div>
                  <div class="toggle-row"><div class="toggle-info"><strong>Show Custom ID</strong></div><button class="toggle" type="button" aria-pressed="false"></button></div>
                  <div class="mention-preview">
                    <div class="mention-chip"><span class="mention-dot"></span><span>Design review feedback</span><span class="mention-status">IN PROGRESS</span><span class="mention-avatar">M</span></div>
                  </div>
                </div>
              </div>
            </section>

            <section class="settings-section">
              <div class="settings-section__label">
                <h2>Danger zone</h2>
                <p>Proceed with caution.</p>
              </div>
              <div class="settings-section__fields danger-zone">
                <div class="danger-row">
                  <span>Log out all sessions including any session on mobile, iPad, and other browsers</span>
                  <button class="btn btn--ghost" type="button">Log out of all sessions</button>
                </div>
                <button class="btn btn--danger" type="button">Delete account</button>
              </div>
            </section>
          }

          <!-- ─── ADMIN › GENERAL ────────────────────────────────── -->
          @case ('general') {
            <h1 class="settings-h1">General</h1>
            <section class="settings-section">
              <div class="settings-section__label">
                <h2>Workspace name</h2>
                <p>The name used across ClickUp for your workspace.</p>
              </div>
              <div class="settings-section__fields">
                <label class="field-label">Name<input class="field-input" type="text" value="Fayoum" /></label>
              </div>
            </section>
          }

          <!-- ─── ADMIN › PEOPLE ────────────────────────────────── -->
          @case ('people') {
            <h1 class="settings-h1">People</h1>
            <p class="settings-empty">Manage members, guests, and permissions for your workspace.</p>
          }

          <!-- ─── ADMIN › TEAMS ─────────────────────────────────── -->
          @case ('teams') {
            <h1 class="settings-h1">Teams</h1>
            <p class="settings-empty">Create and manage teams within your workspace.</p>
          }

          <!-- ─── ADMIN › SECURITY ──────────────────────────────── -->
          @case ('security') {
            <h1 class="settings-h1">Security &amp; Permissions</h1>
            <p class="settings-empty">Configure access control, SSO, and security policies.</p>
          }

          <!-- ─── ADMIN › AUDIT LOGS ───────────────────────────── -->
          @case ('audit-logs') {
            <h1 class="settings-h1">Audit Logs</h1>
            <p class="settings-empty">Review a log of actions taken across your workspace.</p>
          }

          <!-- ─── ADMIN › TRASH ────────────────────────────────── -->
          @case ('trash') {
            <h1 class="settings-h1">Trash</h1>
            <p class="settings-empty">Deleted items are kept here for 30 days before being permanently removed.</p>
          }

          <!-- ─── NOTIFICATIONS ─────────────────────────────────── -->
          @case ('notifications') {
            <h1 class="settings-h1">Notifications</h1>
            <p class="settings-empty">Choose when and how you receive notifications.</p>
          }

          <!-- ─── BILLING / UPGRADE ─────────────────────────────── -->
          @case ('billing') {
            <h1 class="settings-h1">Billing</h1>
            <p class="settings-empty">Manage your subscription and payment methods.</p>
          }
          @case ('upgrade') {
            <h1 class="settings-h1">Upgrade</h1>
            <p class="settings-empty">Explore plans and unlock more features.</p>
          }

          <!-- ─── AI USAGE ──────────────────────────────────────── -->
          @case ('ai-usage') {
            <h1 class="settings-h1">AI Usage</h1>
            <p class="settings-empty">Track your AI feature consumption for this billing period.</p>
          }

          <!-- ─── FEATURES ──────────────────────────────────────── -->
          @case ('custom-fields') {
            <h1 class="settings-h1">Custom Field Manager</h1>
            <p class="settings-empty">Create and manage custom fields across your workspace.</p>
          }
          @case ('tag-manager') {
            <h1 class="settings-h1">Tag Manager</h1>
            <p class="settings-empty">View and edit all tags used in your workspace.</p>
          }
          @case ('template-center') {
            <h1 class="settings-h1">Template Center</h1>
            <p class="settings-empty">Browse and manage templates for tasks, docs, and more.</p>
          }
          @case ('automations') {
            <h1 class="settings-h1">Automations Manager</h1>
            <p class="settings-empty">Build and manage automation rules across your workspace.</p>
          }
          @case ('ai-notetaker') {
            <h1 class="settings-h1">AI Notetaker</h1>
            <p class="settings-empty">Configure AI-powered meeting notes and transcriptions.</p>
          }
          @case ('emojis') {
            <h1 class="settings-h1">Emojis</h1>
            <p class="settings-empty">Manage custom emoji for your workspace.</p>
          }
          @case ('spaces') {
            <h1 class="settings-h1">Spaces</h1>
            <p class="settings-empty">Manage workspace spaces and their settings.</p>
          }
          @case ('task-types') {
            <h1 class="settings-h1">Task Types</h1>
            <p class="settings-empty">Customize the types of tasks available in your workspace.</p>
          }
          @case ('work-schedule') {
            <h1 class="settings-h1">Work Schedule</h1>
            <p class="settings-empty">Set working hours and days for your workspace.</p>
          }

          <!-- ─── INTEGRATIONS ──────────────────────────────────── -->
          @case ('app-center') {
            <h1 class="settings-h1">App Center</h1>
            <p class="settings-empty">Connect third-party tools and integrations.</p>
          }
          @case ('imports-exports') {
            <h1 class="settings-h1">Imports / Exports</h1>
            <p class="settings-empty">Import data from other tools or export your workspace data.</p>
          }
          @case ('clickup-api') {
            <h1 class="settings-h1">ClickUp API</h1>
            <p class="settings-empty">Manage API keys and OAuth apps.</p>
          }
          @case ('email-integration') {
            <h1 class="settings-h1">Email Integration</h1>
            <p class="settings-empty">Connect email accounts to create and receive tasks by email.</p>
          }

          <!-- ─── MY SETTINGS › WORKSPACES ─────────────────────── -->
          @case ('workspaces') {
            <h1 class="settings-h1">Workspaces</h1>
            <p class="settings-empty">Switch between or manage the workspaces you belong to.</p>
          }
          @case ('chat') {
            <h1 class="settings-h1">Chat</h1>
            <p class="settings-empty">Configure your chat notification preferences.</p>
          }
          @case ('referrals') {
            <h1 class="settings-h1">Referrals</h1>
            <p class="settings-empty">Invite friends and earn credits.</p>
          }

          @default {
            <p class="settings-empty">Select a section from the left.</p>
          }
        }

      </div>
      <!-- Sticky save bar -->
      <div class="settings-save-bar">
        <button class="btn btn--primary" type="button">Saved</button>
      </div>
    </div>

  </div>
</div>
  `,
  styles: [`
    /* ── Overlay backdrop ─────────────────────────────────── */
    .settings-overlay {
      position: absolute;
      inset: 0;
      z-index: 30;
      display: flex;
    }

    /* ── Two-column panel ─────────────────────────────────── */
    .settings-panel {
      display: flex;
      width: 100%;
      height: 100%;
      background: var(--color-surface-1);
      overflow: hidden;
    }

    /* ── Left nav ─────────────────────────────────────────── */
    .settings-nav {
      display: flex;
      flex-direction: column;
      width: 13.6rem;
      min-width: 13.6rem;
      height: 100%;
      padding: .6rem .5rem;
      background: var(--color-surface-1);
      border-inline-end: 1px solid var(--color-border);
      overflow-y: auto;
      overflow-x: hidden;
    }
    .settings-nav__header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: .25rem .4rem .6rem;
      margin-bottom: .15rem;
    }
    .settings-nav__title {
      font-size: .92rem;
      font-weight: 700;
      color: var(--color-text-primary);
    }
    .settings-nav__close {
      display: grid;
      place-items: center;
      width: 1.6rem; height: 1.6rem;
      border: 0;
      border-radius: .35rem;
      color: var(--color-text-muted);
      background: transparent;
      cursor: pointer;
    }
    .settings-nav__close:hover { background: var(--color-surface-3); color: var(--color-text-primary); }

    .settings-nav__group-label {
      margin: .65rem 0 .2rem .5rem;
      color: var(--color-text-muted);
      font-size: .61rem;
      font-weight: 800;
      letter-spacing: .07em;
      text-transform: uppercase;
    }
    .settings-nav__item {
      width: 100%;
      min-height: 1.95rem;
      display: flex;
      align-items: center;
      gap: .55rem;
      padding: 0 .55rem;
      border: 0;
      border-radius: .35rem;
      color: var(--color-text-secondary);
      background: transparent;
      font: inherit;
      font-size: .76rem;
      font-weight: 500;
      text-align: start;
      cursor: pointer;
    }
    .settings-nav__item:hover { color: var(--color-text-primary); background: var(--color-surface-3); }
    .settings-nav__item--active { color: var(--color-text-primary); background: var(--color-surface-3); font-weight: 650; }
    .settings-nav__item--danger { color: var(--color-danger, #e5534b); margin-top: .4rem; }
    .settings-nav__item--danger:hover { background: rgba(229,83,75,.1); }

    .settings-nav__footer { margin-top: auto; padding-top: .6rem; border-top: 1px solid var(--color-border); }

    /* ── Right content ────────────────────────────────────── */
    .settings-content {
      flex: 1;
      min-width: 0;
      display: flex;
      flex-direction: column;
      overflow: hidden;
    }
    .settings-content__inner {
      flex: 1;
      padding: 2rem 2.4rem;
      overflow-y: auto;
    }
    .settings-h1 {
      font-size: 1.25rem;
      font-weight: 750;
      color: var(--color-text-primary);
      margin: 0 0 1.6rem;
    }
    .settings-empty {
      color: var(--color-text-secondary);
      font-size: .84rem;
      margin-top: .5rem;
    }

    /* ── Settings section ─────────────────────────────────── */
    .settings-section {
      display: grid;
      grid-template-columns: 18rem 1fr;
      gap: 1.6rem;
      padding: 1.4rem 0;
      border-bottom: 1px solid var(--color-border);
    }
    .settings-section:last-child { border-bottom: 0; }
    .settings-section__label h2 {
      margin: 0 0 .35rem;
      font-size: .88rem;
      font-weight: 700;
      color: var(--color-text-primary);
    }
    .settings-section__label p {
      margin: 0;
      font-size: .76rem;
      color: var(--color-text-secondary);
      line-height: 1.5;
    }
    .settings-section__fields {
      display: flex;
      flex-direction: column;
      gap: .9rem;
    }

    /* ── Avatar ───────────────────────────────────────────── */
    .avatar-row { display: flex; align-items: center; gap: 1rem; }
    .avatar-circle {
      width: 3.5rem; height: 3.5rem;
      display: grid; place-items: center;
      border-radius: 50%;
      background: var(--color-surface-3);
      color: var(--color-text-primary);
      font-size: 1rem; font-weight: 700;
    }
    .avatar-name { margin: 0 0 .25rem; font-size: .83rem; font-weight: 650; color: var(--color-text-primary); }
    .link-btn { border: 0; background: transparent; color: var(--color-accent); font: inherit; font-size: .75rem; cursor: pointer; padding: 0; }

    /* ── Field inputs ─────────────────────────────────────── */
    .field-label {
      display: flex; flex-direction: column; gap: .35rem;
      font-size: .76rem; font-weight: 600; color: var(--color-text-secondary);
    }
    .field-input-wrap {
      display: flex; align-items: center; gap: .5rem;
      padding: 0 .75rem;
      border: 1px solid var(--color-border-strong);
      border-radius: .4rem;
      background: var(--color-surface-2);
      color: var(--color-text-muted);
    }
    .field-input {
      flex: 1; padding: .55rem 0;
      border: 0; background: transparent;
      color: var(--color-text-primary);
      font: inherit; font-size: .8rem;
      outline: none;
    }
    .field-input::placeholder { color: var(--color-text-muted); }
    .field-select-wrap {
      display: flex; align-items: center; gap: .5rem;
      padding: 0 .75rem;
      border: 1px solid var(--color-border-strong);
      border-radius: .4rem;
      background: var(--color-surface-2);
      color: var(--color-text-muted);
    }
    .field-select {
      flex: 1; padding: .55rem 0;
      border: 0; background: transparent;
      color: var(--color-text-primary);
      font: inherit; font-size: .8rem;
      outline: none; cursor: pointer;
      appearance: none;
    }

    /* ── Toggles ──────────────────────────────────────────── */
    .toggle-row {
      display: flex; align-items: flex-start; justify-content: space-between; gap: 1rem;
      padding: .25rem 0;
    }
    .toggle-info { display: flex; flex-direction: column; gap: .2rem; }
    .toggle-info strong { font-size: .8rem; color: var(--color-text-primary); }
    .toggle-info span { font-size: .73rem; color: var(--color-text-secondary); line-height: 1.4; }
    .toggle {
      flex-shrink: 0;
      width: 2.2rem; height: 1.2rem;
      border: 0; border-radius: 99px;
      background: var(--color-surface-3);
      cursor: pointer;
      position: relative; transition: background .18s;
    }
    .toggle::after {
      content: ''; position: absolute;
      top: 2px; left: 2px;
      width: calc(1.2rem - 4px); height: calc(1.2rem - 4px);
      border-radius: 50%; background: #fff;
      transition: left .18s;
    }
    .toggle--on { background: var(--color-accent); }
    .toggle--on::after { left: calc(100% - 1.2rem + 2px); }

    /* ── Theme colors ─────────────────────────────────────── */
    .color-swatches { display: flex; gap: .5rem; flex-wrap: wrap; }
    .swatch {
      width: 1.7rem; height: 1.7rem;
      border-radius: .38rem; border: 2px solid transparent;
      cursor: pointer; transition: border-color .15s;
    }
    .swatch--active { border-color: var(--color-text-primary); }

    /* ── Appearance ───────────────────────────────────────── */
    .appearance-row { display: flex; gap: .7rem; }
    .appearance-btn {
      display: flex; flex-direction: column; align-items: center; gap: .4rem;
      padding: .4rem .5rem; border: 2px solid var(--color-border);
      border-radius: .5rem; background: transparent; cursor: pointer;
      color: var(--color-text-secondary); font: inherit; font-size: .72rem;
    }
    .appearance-btn--active { border-color: var(--color-accent); }
    .appearance-preview {
      width: 4.2rem; height: 2.8rem;
      border-radius: .3rem; overflow: hidden;
      display: flex; flex-direction: column; gap: .3rem; padding: .35rem;
    }
    .appearance-preview--light { background: #f5f5f5; }
    .appearance-preview--dark { background: #1a1b1e; }
    .appearance-preview--auto { background: linear-gradient(135deg,#f5f5f5 50%,#1a1b1e 50%); }
    .appearance-preview span { display: block; height: .4rem; border-radius: 2px; background: var(--color-accent); opacity: .7; }
    .appearance-preview span:last-child { width: 60%; }

    /* ── Radio groups ─────────────────────────────────────── */
    .radio-group {
      border: 0; margin: 0; padding: 0;
      display: flex; flex-direction: column; gap: .55rem;
    }
    .radio-group legend {
      font-size: .75rem; font-weight: 700;
      color: var(--color-text-secondary);
      margin-bottom: .35rem;
    }
    .radio-group label {
      display: flex; align-items: center; gap: .5rem;
      font-size: .8rem; color: var(--color-text-primary); cursor: pointer;
    }
    .checkbox-label {
      display: flex; align-items: center; gap: .5rem;
      font-size: .8rem; color: var(--color-text-primary); cursor: pointer;
    }

    /* ── Badge ────────────────────────────────────────────── */
    .badge--business {
      display: inline-block; padding: .1rem .42rem;
      border-radius: .28rem;
      background: #be185d; color: #fff;
      font-size: .65rem; font-weight: 700;
    }

    /* ── Mention preview ──────────────────────────────────── */
    .task-mention-group { display: flex; flex-direction: column; gap: .6rem; margin-top: .4rem; }
    .task-mention-title { font-size: .82rem; color: var(--color-text-primary); }
    .task-mention-group p { margin: 0; font-size: .75rem; color: var(--color-text-secondary); }
    .mention-preview { padding: .7rem .9rem; border: 1px solid var(--color-border); border-radius: .4rem; background: var(--color-surface-2); }
    .mention-chip { display: inline-flex; align-items: center; gap: .4rem; font-size: .78rem; color: var(--color-text-primary); }
    .mention-dot { width: .5rem; height: .5rem; border-radius: 50%; background: var(--color-accent); }
    .mention-status { padding: .1rem .4rem; border-radius: .25rem; background: #9a6f00; color: #fff; font-size: .62rem; font-weight: 750; }
    .mention-avatar { width: 1.1rem; height: 1.1rem; display: grid; place-items: center; border-radius: 50%; background: var(--color-accent-strong); color: #fff; font-size: .58rem; font-weight: 700; }

    /* ── Danger zone ──────────────────────────────────────── */
    .danger-zone { gap: 1rem; }
    .danger-row { display: flex; align-items: center; justify-content: space-between; gap: 1rem; font-size: .8rem; color: var(--color-text-secondary); }

    /* ── Buttons ──────────────────────────────────────────── */
    .btn { padding: .45rem 1rem; border: 0; border-radius: .38rem; font: inherit; font-size: .78rem; font-weight: 650; cursor: pointer; }
    .btn--primary { background: var(--color-accent); color: #fff; }
    .btn--primary:hover { background: var(--color-accent-strong); }
    .btn--ghost { background: var(--color-surface-3); color: var(--color-text-primary); }
    .btn--ghost:hover { background: var(--color-border); }
    .btn--danger { background: var(--color-danger, #e5534b); color: #fff; }
    .btn--danger:hover { filter: brightness(1.1); }

    /* ── Save bar ─────────────────────────────────────────── */
    .settings-save-bar {
      display: flex; justify-content: flex-end;
      padding: .55rem 1.4rem;
      border-top: 1px solid var(--color-border);
      background: var(--color-surface-1);
    }

    /* ── Responsive ───────────────────────────────────────── */
    @media (max-width: 860px) {
      .settings-section { grid-template-columns: 1fr; }
      .settings-nav { width: 11rem; min-width: 11rem; }
    }
    @media (max-width: 600px) {
      .settings-nav { display: none; }
    }
  `],
})
export class AllSettingsComponent {
  readonly close = output<void>();

  readonly activeSection = signal<SettingsSection>('profile');
  readonly activeTheme = signal('#e91e8c');
  readonly activeAppearance = signal<'light' | 'dark' | 'auto'>('dark');

  readonly X = X; readonly ChevronRight = ChevronRight; readonly User = User;
  readonly Bell = Bell; readonly Briefcase = Briefcase; readonly MessageSquare = MessageSquare;
  readonly Users = Users; readonly Link = Link; readonly LogOut = LogOut;
  readonly Settings = Settings; readonly Shield = Shield; readonly Trash2 = Trash2;
  readonly Zap = Zap; readonly Globe = Globe; readonly Clock = Clock;
  readonly ToggleLeft = ToggleLeft; readonly Tag = Tag; readonly Layout = Layout;
  readonly Cpu = Cpu; readonly Smile = Smile; readonly Box = Box;
  readonly ClipboardList = ClipboardList; readonly Key = Key;
  readonly BarChart2 = BarChart2; readonly Mail = Mail;

  readonly themeColors = [
    { label: 'Gray',    value: '#6b7280' },
    { label: 'Violet',  value: '#7c3aed' },
    { label: 'Cyan',    value: '#0891b2' },
    { label: 'Pink',    value: '#e91e8c' },
    { label: 'Purple',  value: '#a21caf' },
    { label: 'Indigo',  value: '#4338ca' },
    { label: 'Orange',  value: '#ea580c' },
    { label: 'Teal',    value: '#0d9488' },
    { label: 'Tan',     value: '#92400e' },
    { label: 'Green',   value: '#16a34a' },
  ];

  appPreferences = [
    { key: 'toast',       label: 'Flyout Toast Message',       description: 'When performing actions, toast messages may appear in the bottom left-hand of your screen.',  on: true  },
    { key: 'enter',       label: 'Don\'t post comments with Enter', description: 'Use Ctrl + Enter to send comments instead of just Enter.',                              on: false },
    { key: 'shortcuts',   label: 'Keyboard Shortcuts',          description: 'Use keyboard shortcuts to quickly navigate and take action through ClickUp.',                on: false },
    { key: 'markdown',    label: 'Markdown',                   description: 'You can disable Markdown (shortcuts when typing) by turning it off here.',                   on: true  },
    { key: 'quotes',      label: 'Show quotes',                description: 'Show celebratory quotes when you clear all your notifications or load certain pages.',        on: true  },
    { key: 'celebrate',   label: 'Show Celebrations',          description: 'Show confetti celebrations when you clear My Work, clear all notifications, or complete a Goal Target.', on: true },
    { key: 'verified',    label: 'ClickUp Verified',           description: 'You can disable your ClickUp Verified checkmark.',                                           on: true  },
    { key: 'perf',        label: 'Performance mode',           description: 'Enhance performance by turning off non-essential features like product guides and certain visuals.', on: false },
    { key: 'desktop',     label: 'Detect Desktop App',         description: 'Automatically open links in the desktop app when it\'s running.',                            on: false },
    { key: 'selectall',   label: 'Block Select All',           description: 'Press Cmd + A to select all text in the current block, press again to select all.',          on: true  },
    { key: 'tablimits',   label: 'Browser Tab Limits',         description: 'Set how many ClickUp tabs can be active at the same time.',                                  on: true  },
    { key: 'askpriority', label: 'Ask to add task to priorities after assigning', description: 'Show a prompt asking if you\'d like to add the task to assigned member\'s priorities.', on: true },
  ];

  readonly navGroups: NavGroup[] = [
    {
      heading: 'Admin',
      items: [
        { id: 'general',      label: 'General',               icon: Settings    },
        { id: 'people',       label: 'People',                icon: Users       },
        { id: 'teams',        label: 'Teams',                 icon: Briefcase   },
        { id: 'upgrade',      label: 'Upgrade',               icon: Zap         },
        { id: 'billing',      label: 'Billing',               icon: ClipboardList },
        { id: 'ai-usage',     label: 'AI Usage',              icon: BarChart2   },
        { id: 'security',     label: 'Security & Permissions',icon: Shield      },
        { id: 'audit-logs',   label: 'Audit Logs',            icon: Key         },
        { id: 'trash',        label: 'Trash',                 icon: Trash2      },
      ],
    },
    {
      heading: 'Features',
      items: [
        { id: 'custom-fields',   label: 'Custom Field Manager', icon: Layout   },
        { id: 'tag-manager',     label: 'Tag Manager',          icon: Tag      },
        { id: 'template-center', label: 'Template Center',      icon: Box      },
        { id: 'automations',     label: 'Automations Manager',  icon: Cpu      },
        { id: 'ai-notetaker',    label: 'AI Notetaker',         icon: MessageSquare },
        { id: 'emojis',          label: 'Emojis',               icon: Smile    },
        { id: 'spaces',          label: 'Spaces',               icon: Layout   },
        { id: 'task-types',      label: 'Task Types',           icon: ClipboardList },
        { id: 'work-schedule',   label: 'Work Schedule',        icon: Clock    },
      ],
    },
    {
      heading: 'Integrations & ClickApps',
      items: [
        { id: 'app-center',        label: 'App Center',        icon: Box       },
        { id: 'imports-exports',   label: 'Imports / Exports', icon: Link      },
        { id: 'clickup-api',       label: 'ClickUp API',       icon: Key       },
        { id: 'email-integration', label: 'Email Integration', icon: Mail      },
      ],
    },
    {
      heading: 'My Settings',
      items: [
        { id: 'preferences',  label: 'Preferences',  icon: Settings      },
        { id: 'notifications',label: 'Notifications',icon: Bell          },
        { id: 'workspaces',   label: 'Workspaces',   icon: Briefcase     },
        { id: 'chat',         label: 'Chat',         icon: MessageSquare },
        { id: 'referrals',    label: 'Referrals',    icon: Users         },
      ],
    },
    {
      heading: null,
      items: [
        { id: 'profile', label: 'Profile', icon: User },
      ],
    },
  ];

  onBackdropClick(_e: MouseEvent): void {
    // only close when clicking the bare overlay, not the panel (panel stops propagation)
  }
}
