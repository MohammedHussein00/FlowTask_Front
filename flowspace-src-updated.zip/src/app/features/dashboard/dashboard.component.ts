/** ClickUp reference fidelity: compact Space tabs, accent-tinted announcement strip, and three overview cards. */
import { ChangeDetectionStrategy, Component, computed, signal } from '@angular/core';
import {
  LucideAngularModule, Bookmark, BrainCircuit, ChevronDown, FileText, Folder, LayoutDashboard, Link2, ListFilter,
  ListTodo, Phone, Plus, RefreshCw, Share2, Star, Workflow, X,
} from 'lucide-angular';

@Component({ selector: 'app-dashboard', standalone: true, imports: [LucideAngularModule], changeDetection: ChangeDetectionStrategy.OnPush, template: `
  <section class="overview">
    <header class="space-tabs">
      <button type="button" class="space-title"><b>S</b>Space<lucide-icon [img]="ChevronDown" size="14" /><lucide-icon [img]="Star" size="14" /></button>
      <button type="button" class="tab">Add Channel</button>
      <button type="button" class="tab tab--active">Overview</button>
      <button type="button" class="tab"><lucide-icon [img]="ListTodo" size="14" />List</button>
      <button type="button" class="tab"><lucide-icon [img]="LayoutDashboard" size="14" />Board</button>
      <button type="button" class="tab"><lucide-icon [img]="Plus" size="14" />View</button>
      <div class="space-tabs__actions">
        <button type="button" class="space-tabs__action"><lucide-icon [img]="Phone" size="14" />Call<lucide-icon [img]="ChevronDown" size="12" /></button>
        <button type="button" class="space-tabs__action space-tabs__action--icon" aria-label="Connections"><lucide-icon [img]="Link2" size="15" /></button>
        <button type="button" class="space-tabs__action"><lucide-icon [img]="Workflow" size="14" />Automate</button>
        <button type="button" class="space-tabs__action"><lucide-icon [img]="BrainCircuit" size="14" />Brain<sup>2</sup></button>
        <button type="button" class="space-tabs__action space-tabs__action--share"><lucide-icon [img]="Share2" size="14" />Share</button>
      </div>
    </header>

    <div class="overview-notice"><span>Get the most out of your Overview! Add, reorder, and resize cards to customize this page </span><button type="button">Get Started</button><button type="button" aria-label="Dismiss notice"><lucide-icon [img]="X" size="16" /></button></div>

    <div class="overview-toolbar">
      <button type="button" class="filter"><lucide-icon [img]="ListFilter" size="15" />Filters</button>
      <div>
        <span><lucide-icon [img]="RefreshCw" size="14" [class.spin]="refreshing()" />{{ refreshLabel() }}</span>
        <button type="button" class="autorefresh">Auto refresh: On</button>
        <button type="button" class="customize">Customize</button>
        <button type="button" class="btn-accent btn-accent--sm">Add card</button>
      </div>
    </div>

    <div class="card-grid">
      <article class="overview-card"><h2>Recent</h2><div class="card-empty"><div class="recent-glyph"><lucide-icon [img]="RefreshCw" size="29" /></div><p>Your recently opened items will appear here.</p><button type="button" class="btn-accent btn-accent--sm">Learn more</button></div></article>
      <article class="overview-card"><h2>Docs</h2><div class="card-empty"><lucide-icon [img]="FileText" size="47" strokeWidth="1.25" /><p>There are no Docs in this location yet.</p><button type="button" class="btn-accent btn-accent--sm">Add a Doc</button></div></article>
      <article class="overview-card"><h2>Bookmarks</h2><div class="card-empty"><div class="bookmark-glyph"><lucide-icon [img]="Bookmark" size="26" /><b>+</b></div><p>Bookmarks make it easy to save Flowspace items or any URL from around the web.</p><button type="button" class="btn-accent btn-accent--sm">Add Bookmark</button></div></article>
    </div>

    <article class="folders"><h2>Folders</h2><div><lucide-icon [img]="Folder" size="54" strokeWidth="1.25" /></div></article>
  </section>
`, styles: [`
  :host { display: block; height: 100%; }
  .overview { min-height: calc(100vh - 2.65rem); color: var(--color-text-primary); background: var(--color-canvas); }
  .space-tabs { height: 4.25rem; display: flex; align-items: flex-end; gap: .5rem; padding: 0 .95rem; border-bottom: 1px solid var(--color-border); }
  .space-tabs button { height: 2.15rem; display: inline-flex; align-items: center; gap: .3rem; border: 0; border-bottom: 2px solid transparent; color: var(--color-text-muted); background: transparent; font: inherit; font-size: .69rem; font-weight: 700; cursor: pointer; }
  .space-title { margin-inline-end: .25rem; color: var(--color-text-primary) !important; }
  .space-title b { width: 1.05rem; height: 1.05rem; display: grid; place-items: center; border-radius: .28rem; color: #fff; background: var(--color-accent); font-size: .57rem; }
  .tab:first-of-type { align-self: flex-start; height: 1.85rem; margin-top: .55rem; padding: 0 .4rem; border: 1px solid var(--color-border-strong); border-radius: .32rem; }
  .tab--active { color: var(--color-text-primary) !important; border-color: var(--color-accent) !important; }
  .space-tabs__actions { align-self: center; display: flex; align-items: center; gap: .3rem; margin-inline-start: auto; }
  .space-tabs__action { height: 1.8rem !important; border-radius: .35rem; padding: 0 .5rem; color: var(--color-text-muted); background: transparent; font-weight: 650 !important; white-space: nowrap; }
  .space-tabs__action:hover { color: var(--color-text-primary); background: var(--color-surface-3); }
  .space-tabs__action--icon { width: 1.8rem; padding: 0; }
  .space-tabs__action--share { color: #fff; background: var(--color-accent); }
  .space-tabs__action--share:hover { background: var(--color-accent-strong); }
  .space-tabs__action sup { font-size: .55rem; }
  .overview-notice { position: relative; min-height: 2.65rem; display: flex; align-items: center; justify-content: center; gap: .22rem; padding: .45rem 2.8rem; color: #f5f1ff; background: color-mix(in srgb, var(--color-accent) 34%, #1a1424); font-size: .7rem; text-align: center; }
  .overview-notice button { border: 0; color: #fff; background: transparent; font: inherit; font-size: .7rem; font-weight: 800; text-decoration: underline; cursor: pointer; }
  .overview-notice button:last-child { position: absolute; inset-inline-end: .95rem; color: var(--color-accent-bright); text-decoration: none; }
  .overview-toolbar { min-height: 3.55rem; display: flex; justify-content: space-between; align-items: center; padding: 0 .85rem; }
  .filter { min-height: 1.75rem; display: inline-flex; align-items: center; gap: .35rem; border: 1px solid var(--color-border-strong); border-radius: .8rem; padding: 0 .65rem; color: var(--color-text-muted); background: transparent; font: inherit; font-size: .67rem; cursor: pointer; }
  .overview-toolbar > div { display: flex; align-items: center; gap: .5rem; }
  .overview-toolbar span { display: inline-flex; align-items: center; gap: .3rem; min-width: 7.4rem; color: var(--color-text-muted); font-size: .64rem; }
  .autorefresh { min-height: 1.7rem; border: 0; border-radius: .7rem; padding: 0 .55rem; color: var(--color-accent-bright); background: color-mix(in srgb, var(--color-accent) 40%, transparent); font: inherit; font-size: .63rem; }
  .customize { border: 0; color: var(--color-text-secondary); background: transparent; font: inherit; font-size: .66rem; cursor: pointer; }
  .btn-accent { display: inline-flex; align-items: center; justify-content: center; border: 0; border-radius: .4rem; color: #fff; background: var(--color-accent); font: inherit; font-weight: 700; cursor: pointer; transition: background .12s ease; }
  .btn-accent:hover { background: var(--color-accent-strong); }
  .btn-accent--sm { min-height: 1.85rem; padding: 0 .7rem; font-size: .66rem; }
  .spin { animation: dash-spin 1.1s linear infinite; }
  @keyframes dash-spin { to { transform: rotate(360deg); } }
  .card-grid { display: grid; grid-template-columns: repeat(3,minmax(0,1fr)); gap: .75rem; padding: 0 .75rem .75rem; }
  .overview-card, .folders { min-height: 18.6rem; overflow: hidden; border: 1px solid var(--color-border); border-radius: .75rem; background: var(--color-surface-1); }
  .overview-card h2, .folders h2 { margin: 1rem 1rem 0; color: var(--color-text-primary); font-size: .73rem; }
  .card-empty { min-height: 14.4rem; display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 1rem 1.5rem; color: var(--color-text-muted); text-align: center; }
  .card-empty > lucide-icon { margin-bottom: .85rem; }
  .card-empty p { max-width: 16rem; min-height: 2rem; margin: 0 0 .65rem; color: var(--color-text-secondary); font-size: .63rem; line-height: 1.55; }
  .recent-glyph { width: 3rem; height: 3rem; display: grid; place-items: center; margin-bottom: .85rem; border: 1px solid var(--color-border-strong); border-radius: 1rem; color: var(--color-text-muted); }
  .bookmark-glyph { position: relative; width: 3.25rem; height: 3.6rem; display: grid; place-items: center; margin-bottom: .85rem; border: 1px solid var(--color-border-strong); border-radius: 1rem; color: var(--color-text-muted); }
  .bookmark-glyph b { position: absolute; inset-inline-end: -.5rem; inset-block-end: -.3rem; width: 1.15rem; height: 1.15rem; display: grid; place-items: center; border-radius: 50%; color: #fff; background: var(--color-text-muted); font-size: .75rem; }
  .folders { min-height: 12rem; margin: 0 .75rem; }
  .folders > div { min-height: 8rem; display: grid; place-items: center; color: var(--color-text-muted); }
  @media (max-width: 1100px) { .space-tabs__action span, .space-tabs__action { font-size: .6rem; } }
  @media (max-width: 900px) { .card-grid { grid-template-columns: 1fr 1fr; }.overview-card:last-child { grid-column: span 2; }.space-tabs__actions { display: none; } }
  @media (max-width: 600px) { .overview { min-height: calc(100vh - 3rem); }.space-tabs { height: 3.65rem; overflow-x: auto; padding-inline: .65rem; white-space: nowrap; }.tab:first-of-type { display: none; }.overview-notice { justify-content: flex-start; padding-inline: .65rem 2.2rem; text-align: left; }.overview-toolbar { align-items: flex-start; flex-direction: column; gap: .45rem; padding: .65rem; }.overview-toolbar > div { flex-wrap: wrap; }.overview-toolbar span, .customize { display: none; }.card-grid { grid-template-columns: 1fr; padding-inline: .55rem; }.overview-card:last-child { grid-column: auto; }.overview-card { min-height: 14rem; }.card-empty { min-height: 10.4rem; }.folders { margin-inline: .55rem; } }
`]
})
export class DashboardComponent {
  readonly Bookmark = Bookmark; readonly BrainCircuit = BrainCircuit; readonly ChevronDown = ChevronDown;
  readonly FileText = FileText; readonly Folder = Folder; readonly LayoutDashboard = LayoutDashboard;
  readonly Link2 = Link2; readonly ListFilter = ListFilter; readonly ListTodo = ListTodo; readonly Phone = Phone;
  readonly Plus = Plus; readonly RefreshCw = RefreshCw; readonly Share2 = Share2; readonly Star = Star;
  readonly Workflow = Workflow; readonly X = X;

  private readonly minutesSinceRefresh = signal(0);
  readonly refreshing = computed(() => this.minutesSinceRefresh() === 0);
  readonly refreshLabel = computed(() => {
    const minutes = this.minutesSinceRefresh();
    if (minutes === 0) return 'Refreshing...';
    return `Refreshed: ${minutes} min${minutes === 1 ? '' : 's'} ago`;
  });

  constructor() {
    setInterval(() => this.minutesSinceRefresh.update(value => value + 1), 60_000);
  }
}
