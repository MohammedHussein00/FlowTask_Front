import { Routes } from '@angular/router';

export const WORKSPACE_ROUTES: Routes = [
  { path: '', loadComponent: () => import('../dashboard/dashboard.component').then(m => m.DashboardComponent) },
];
