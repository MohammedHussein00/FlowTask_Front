/** ClickUp reference fidelity: a full-width top bar, global rail, contextual navigation, and layered utility overlays. */
import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import {
  LucideAngularModule, Clapperboard, ClipboardList, FileText, Grid2X2, LayoutDashboard, LayoutGrid,
  MessageCircle, PanelLeftOpen, PenLine, Settings2, Sparkles, Target, Timer, UserPlus,
} from 'lucide-angular';
import { AllSettingsComponent } from '../../features/all-settings/all-settings.component';
import { AppCustomizerComponent } from '../../shared/components/app-customizer/app-customizer.component';
import { AppSidebarComponent } from '../../shared/components/app-sidebar/app-sidebar.component';
import { AppTopbarComponent } from '../../shared/components/app-topbar/app-topbar.component';
import { InviteModalComponent } from '../../shared/components/modals/invite-modal/invite-modal.component';
import { UpgradeModalComponent } from '../../shared/components/modals/upgrade-modal/upgrade-modal.component';
import { NotificationService } from '../../core/errors/notification.service';
import { WorkspaceCustomizationService } from '../../core/theme/workspace-customization.service';

@Component({
  selector: 'app-shell',
  standalone: true,
  imports: [RouterOutlet, RouterLink, RouterLinkActive, AppSidebarComponent, AppTopbarComponent, AppCustomizerComponent, AllSettingsComponent, InviteModalComponent, UpgradeModalComponent, LucideAngularModule],
  templateUrl: './shell.component.html',
  styleUrl: './shell.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ShellComponent {
  readonly notifications = inject(NotificationService);
  readonly workspace = inject(WorkspaceCustomizationService);

  /** Rail items actually shown — driven by the "Navigation" tab in Customize (see workspace-customization.service.ts). */
  readonly checkedRailItems = computed(() => this.workspace.railItems().filter(item => item.checked));

  readonly sidebarCollapsed = signal(false);
  readonly customizerOpen = signal(false);
  readonly moreRailOpen = signal(false);
  readonly inviteOpen = signal(false);
  readonly upgradeOpen = signal(false);
  readonly settingsOpen = signal(false);

  readonly Clapperboard = Clapperboard;
  readonly ClipboardList = ClipboardList;
  readonly FileText = FileText;
  readonly Grid2X2 = Grid2X2;
  readonly LayoutDashboard = LayoutDashboard;
  readonly LayoutGrid = LayoutGrid;
  readonly MessageCircle = MessageCircle;
  readonly PanelLeftOpen = PanelLeftOpen;
  readonly PenLine = PenLine;
  readonly Settings2 = Settings2;
  readonly Sparkles = Sparkles;
  readonly Target = Target;
  readonly Timer = Timer;
  readonly UserPlus = UserPlus;

  toggleSidebar(): void { this.sidebarCollapsed.update(value => !value); }
  openSettings(): void { this.settingsOpen.set(true); }
  closeSettings(): void { this.settingsOpen.set(false); }
  openCustomizer(): void { this.customizerOpen.set(true); }
  closeCustomizer(): void { this.customizerOpen.set(false); }
  openInvite(): void { this.inviteOpen.set(true); }
  closeInvite(): void { this.inviteOpen.set(false); }
  openUpgrade(): void { this.upgradeOpen.set(true); }
  closeUpgrade(): void { this.upgradeOpen.set(false); }
}
