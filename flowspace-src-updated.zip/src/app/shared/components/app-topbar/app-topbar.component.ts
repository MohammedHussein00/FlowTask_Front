/** ClickUp reference fidelity: full-width top bar with workspace switcher, global search, quick actions, and account menu. */
import { ChangeDetectionStrategy, Component, inject, output, signal } from '@angular/core';
import {
  LucideAngularModule, AlarmClock, Bell, Briefcase, Calendar, Camera, ChevronDown, ChevronRight,
  CircleHelp, CircleUserRound, Clapperboard, Clock, Download, ExternalLink, FileText,
  Keyboard, LayoutDashboard, ListChecks, Mic, NotebookPen, Palette, PenLine, Pin, Search, Settings2,
  Sparkles, Users, Video, VolumeX,
} from 'lucide-angular';
import { NzInputModule } from 'ng-zorro-antd/input';
import { LocaleService, LOCALES } from '../../../core/i18n/locale.service';
import { ThemeService } from '../../../core/theme/theme.service';

@Component({ selector: 'app-topbar', standalone: true, imports: [LucideAngularModule, NzInputModule], changeDetection: ChangeDetectionStrategy.OnPush, template: `
  <header class="topbar">
    <div class="topbar__brand">
      <button class="workspace-switch" type="button" aria-label="Switch workspace"><span class="workspace-switch__mark">F</span><strong>Fayoum</strong><lucide-icon [img]="ChevronDown" size="14" /></button>
      <button class="icon-btn" type="button" aria-label="Calendar"><lucide-icon [img]="Calendar" size="17" /></button>
    </div>

    <label class="search"><lucide-icon [img]="Search" size="16" /><input nz-input type="search" placeholder="Search" /><kbd>Ctrl K</kbd></label>

    <button class="ai-trigger" type="button">AI Chats <span>✦</span></button>

    <div class="actions">
      <button type="button" aria-label="Screen record"><lucide-icon [img]="Camera" size="17" /></button>
      <button type="button" aria-label="Start video"><lucide-icon [img]="Video" size="17" /></button>
      <button type="button" aria-label="Voice message"><lucide-icon [img]="Mic" size="17" /></button>
      <button class="account" type="button" (click)="profileOpen.update(value => !value)"><b>MM</b><span class="status-dot"></span><lucide-icon [img]="ChevronDown" size="13" /></button>
    </div>

    @if (profileOpen()) {
      <section class="profile-menu" role="menu">
        <header><b>MM</b><div><strong>Muhammed Hussein S.</strong><small>Online</small></div></header>
        <button type="button"><lucide-icon [img]="CircleUserRound" size="16" />Set status</button>
        <button type="button"><lucide-icon [img]="VolumeX" size="16" />Mute notifications<lucide-icon class="chev" [img]="ChevronRight" size="13" /></button>
        <div></div>
        <button type="button" (click)="openSettings.emit(); profileOpen.set(false)"><lucide-icon [img]="Settings2" size="16" />Settings</button>
        <button type="button"><lucide-icon [img]="Bell" size="16" />Notifications</button>
        <button type="button" (click)="settings.emit(); profileOpen.set(false)"><lucide-icon [img]="Palette" size="16" />Themes</button>
        <button type="button"><lucide-icon [img]="Keyboard" size="16" />Keyboard shortcuts</button>
        <button type="button"><lucide-icon [img]="Download" size="16" />Download ClickUp<lucide-icon class="ext" [img]="ExternalLink" size="12" /></button>
        <button type="button"><lucide-icon [img]="CircleHelp" size="16" />Help<lucide-icon class="chev" [img]="ChevronRight" size="13" /></button>
        <div></div>
        <p>PERSONAL TOOLS</p>
        <button type="button"><lucide-icon [img]="ListChecks" size="16" />Create task<lucide-icon class="pin" [img]="Pin" size="13" /></button>
        <button type="button"><lucide-icon [img]="Briefcase" size="16" />My Work</button>
        <button type="button"><lucide-icon [img]="Clock" size="16" />Track Time</button>
        <button type="button"><lucide-icon [img]="NotebookPen" size="16" />Notepad</button>
        <button type="button"><lucide-icon [img]="Clapperboard" size="16" />Record a Clip<lucide-icon class="pin" [img]="Pin" size="13" /></button>
        <button type="button"><lucide-icon [img]="Mic" size="16" />Talk to Text<lucide-icon class="pin" [img]="Pin" size="13" /></button>
        <button type="button"><lucide-icon [img]="AlarmClock" size="16" />Create Reminder</button>
        <button type="button"><lucide-icon [img]="FileText" size="16" />Create Doc</button>
        <button type="button"><lucide-icon [img]="PenLine" size="16" />Create Whiteboard</button>
        <button type="button"><lucide-icon [img]="Users" size="16" />View People</button>
        <button type="button"><lucide-icon [img]="LayoutDashboard" size="16" />Create Dashboard<lucide-icon class="pin" [img]="Pin" size="13" /></button>
        <button type="button"><lucide-icon [img]="Sparkles" size="16" />AI Notetaker</button>
      </section>
    }
  </header>
`, styles: [`
  :host { display: block; }
  .topbar { position: relative; z-index: 10; min-height: 2.7rem; display: grid; grid-template-columns: auto minmax(12rem,19.5rem) auto 1fr auto; align-items: center; gap: .65rem; padding: 0 .8rem; color: var(--color-text-primary); background: var(--color-surface-1); border-bottom: 1px solid var(--color-border); }
  .topbar__brand { display: flex; align-items: center; gap: .2rem; }
  .workspace-switch { display: inline-flex; align-items: center; gap: .38rem; height: 1.85rem; padding: 0 .4rem; border: 0; border-radius: .4rem; color: var(--color-text-primary); background: transparent; font: inherit; font-size: .74rem; font-weight: 750; cursor: pointer; }
  .workspace-switch:hover { background: var(--color-surface-3); }
  .workspace-switch__mark { width: 1.2rem; height: 1.2rem; display: grid; place-items: center; border-radius: .32rem; color: #08341f; background: #35bd7d; font-size: .62rem; font-weight: 800; }
  .icon-btn { width: 1.85rem; height: 1.85rem; display: grid; place-items: center; border: 0; border-radius: .35rem; color: var(--color-text-muted); background: transparent; cursor: pointer; }
  .icon-btn:hover { color: #fff; background: var(--color-surface-3); }
  .search { width: 100%; min-height: 1.75rem; display: flex; align-items: center; gap: .35rem; padding: 0 .55rem; border: 1px solid var(--color-border); border-radius: .75rem; color: var(--color-text-muted); background: var(--color-surface-2); }
  .search input[nz-input] { min-width: 0; padding: 0; border: 0; outline: 0; box-shadow: none; color: var(--color-text-primary); background: transparent; font: inherit; font-size: .68rem; }
  .search input::placeholder { color: var(--color-text-muted); }
  .search kbd { margin-inline-start: auto; color: var(--color-text-muted); font-size: .61rem; }
  .ai-trigger { justify-self: start; display: flex; align-items: center; gap: .25rem; border: 0; color: var(--color-text-muted); background: transparent; font: inherit; font-size: .68rem; cursor: pointer; }
  .ai-trigger span { color: var(--color-accent-bright); }
  .actions { justify-self: end; display: flex; align-items: center; gap: .2rem; }
  .actions > button { width: 1.85rem; height: 1.85rem; display: grid; place-items: center; border: 0; border-radius: .35rem; color: var(--color-text-muted); background: transparent; cursor: pointer; }
  .actions > button:hover { color: #fff; background: var(--color-surface-3); }
  .account { position: relative; display: flex !important; align-items: center; justify-content: center; gap: .25rem; width: auto !important; padding: 0 .1rem; }
  .account > b { width: 1.8rem; height: 1.8rem; display: grid; place-items: center; border-radius: 50%; color: #24252a; background: #eeeef0; font-size: .62rem; }
  .status-dot { position: absolute; inset-inline-end: .3rem; inset-block-end: .1rem; width: .42rem; height: .42rem; border: 1px solid var(--color-surface-1); border-radius: 50%; background: #35bd7d; }
  .profile-menu { position: absolute; z-index: 9; inset-block-start: 2.7rem; inset-inline-end: .35rem; width: 17.3rem; max-height: calc(100vh - 3rem); overflow-y: auto; padding: .5rem; border: 1px solid var(--color-border-strong); border-radius: .65rem; background: var(--color-surface-2); box-shadow: 0 1.1rem 2.8rem rgb(0 0 0 / .5); }
  .profile-menu header { display: flex; align-items: center; gap: .55rem; padding: .3rem .25rem .65rem; }
  .profile-menu header > b { width: 1.8rem; height: 1.8rem; display: grid; place-items: center; border-radius: 50%; color: #24252a; background: #eeeef0; font-size: .62rem; }
  .profile-menu header strong, .profile-menu header small { display: block; }
  .profile-menu header strong { color: var(--color-text-primary); font-size: .73rem; }
  .profile-menu header small { margin-top: .12rem; color: var(--color-success-text); font-size: .61rem; }
  .profile-menu > button { position: relative; width: 100%; min-height: 1.9rem; display: flex; align-items: center; gap: .55rem; padding: 0 .4rem; border: 0; border-radius: .3rem; color: var(--color-text-secondary); background: transparent; font: inherit; font-size: .72rem; text-align: start; cursor: pointer; }
  .profile-menu > button:hover { background: var(--color-surface-3); }
  .profile-menu > button .chev, .profile-menu > button .ext, .profile-menu > button .pin { margin-inline-start: auto; color: var(--color-text-muted); }
  .profile-menu > div { height: 1px; margin: .38rem 0; background: var(--color-border); }
  .profile-menu p { margin: .45rem .38rem .25rem; color: var(--color-text-muted); font-size: .56rem; font-weight: 800; letter-spacing: .08em; }
  @media (max-width: 720px) { .topbar { grid-template-columns: auto 1fr auto; min-height: 3rem; }.ai-trigger { display: none; }.search { width: 100%; }.actions > button:not(.account) { display: none; }.search kbd { display: none; }.profile-menu { inset-block-start: 3rem; } }
`]
})
export class AppTopbarComponent {
  readonly locale = inject(LocaleService);
  readonly theme = inject(ThemeService);
  readonly locales = LOCALES;
  readonly settings = output<void>();
  readonly openSettings = output<void>();
  readonly profileOpen = signal(false);

  readonly AlarmClock = AlarmClock; readonly Bell = Bell; readonly Briefcase = Briefcase; readonly Calendar = Calendar;
  readonly Camera = Camera; readonly ChevronDown = ChevronDown; readonly ChevronRight = ChevronRight;
  readonly CircleHelp = CircleHelp; readonly CircleUserRound = CircleUserRound; readonly Clapperboard = Clapperboard;
  readonly Clock = Clock; readonly Download = Download; readonly ExternalLink = ExternalLink; readonly FileText = FileText;
  readonly Keyboard = Keyboard; readonly LayoutDashboard = LayoutDashboard; readonly ListChecks = ListChecks; readonly Mic = Mic;
  readonly NotebookPen = NotebookPen; readonly Palette = Palette; readonly PenLine = PenLine; readonly Pin = Pin;
  readonly Search = Search; readonly Settings2 = Settings2; readonly Sparkles = Sparkles; readonly Users = Users;
  readonly Video = Video; readonly VolumeX = VolumeX;
}
