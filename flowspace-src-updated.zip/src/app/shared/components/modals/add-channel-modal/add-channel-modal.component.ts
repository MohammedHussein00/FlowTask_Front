/** TODO: implement app-add-channel-modal. Scaffolded to match the Flowspace/ClickUp reference layout; content not yet built. */
import { ChangeDetectionStrategy, Component, output } from '@angular/core';

@Component({
  selector: 'app-add-channel-modal',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: ``,
  styles: [``],
})
export class AddChannelModalComponent {
  readonly close = output<void>();
}
