/** TODO: implement app-add-item-modal. Scaffolded to match the Flowspace/ClickUp reference layout; content not yet built. */
import { ChangeDetectionStrategy, Component, output } from '@angular/core';

@Component({
  selector: 'app-add-item-modal',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: ``,
  styles: [``],
})
export class AddItemModalComponent {
  readonly close = output<void>();
}
