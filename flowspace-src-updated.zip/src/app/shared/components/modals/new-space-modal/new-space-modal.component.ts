/** TODO: implement app-new-space-modal. Scaffolded to match the Flowspace/ClickUp reference layout; content not yet built. */
import { ChangeDetectionStrategy, Component, output } from '@angular/core';

@Component({
  selector: 'app-new-space-modal',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: ``,
  styles: [``],
})
export class NewSpaceModalComponent {
  readonly close = output<void>();
}
