export const environment = {
  production: false,
  graphqlUrl: 'https://localhost:7004/graphql',
  oauth: {
    googleClientId: '',
    githubClientId: '',
  },
};
