import {
  ChangeDetectionStrategy, ChangeDetectorRef, Component, inject,
  input, output, signal,
} from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';
import {
  LucideAngularModule,
  ChevronRight, ChevronDown, Lock, MoreHorizontal, Plus,
} from 'lucide-angular';
import { NzPopoverModule, NzPopoverDirective } from 'ng-zorro-antd/popover';
import { SpaceContextMenuComponent } from '../popovers/space-context-menu.component';
import { CreateMenuComponent } from '../popovers/create-menu.component';

export interface SidebarSpace {
  id: number;
  name: string;
  color: string;
  isPrivate?: boolean;
}

@Component({
  selector: 'app-space-row',
  standalone: true,
  imports: [
    RouterLink, RouterLinkActive, LucideAngularModule,
    NzPopoverModule, SpaceContextMenuComponent, CreateMenuComponent,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-row-wrap"
      (mouseenter)="hovered.set(true)"
      (mouseleave)="hovered.set(false)">

      @if (hovered()) {
        <div class="space-tooltip">Create Folders, Lists, Docs and more</div>
      }

      <a class="space-row" routerLink="/all-spaces" routerLinkActive="space-row--selected">
        <button class="space-chevron" type="button"
          (click)="$event.preventDefault(); expandToggle.emit(space().id)">
          <lucide-icon [img]="expanded() ? ChevronDown : ChevronRight" size="12"/>
        </button>
        <b class="space-badge" [style.background]="space().color">
          {{ space().name.charAt(0).toUpperCase() }}
        </b>
        <span class="space-name">{{ space().name }}</span>
        @if (space().isPrivate) {
          <lucide-icon [img]="Lock" size="12" class="space-row__lock"/>
        }

        <div class="space-row-actions">
          <!-- ··· 3-dots context menu ··· -->
          <!--
            KEY FIX: NO [nzPopoverVisible] binding here.
            [nzPopoverVisible] + .hide() fight each other:
            ng-zorro starts the leave animation, then Angular re-runs CD with
            [nzPopoverVisible]=false, causing the overlay to lose its anchor
            and snap to [0,0] before fading. Without the binding, .hide()
            synchronously detaches the CDK overlay with no animation race.
          -->
          <button class="space-action-btn" type="button"
            #contextRef="nzPopover"
            nz-popover
            [nzPopoverContent]="contextTpl"
            nzPopoverTrigger="click"
            nzPopoverPlacement="rightTop"
            nzPopoverOverlayClassName="sb-popover"
            (nzPopoverVisibleChange)="onOpen($event, contextRef)"
            (click)="$event.preventDefault(); $event.stopPropagation()">
            <lucide-icon [img]="MoreHorizontal" size="14"/>
          </button>

          <!-- ··· + create ··· -->
          <button class="space-action-btn" type="button"
            #createRef="nzPopover"
            nz-popover
            [nzPopoverContent]="createTpl"
            nzPopoverTrigger="click"
            nzPopoverPlacement="rightTop"
            nzPopoverOverlayClassName="sb-popover"
            (nzPopoverVisibleChange)="onOpen($event, createRef)"
            (click)="$event.preventDefault(); $event.stopPropagation()">
            <lucide-icon [img]="Plus" size="14"/>
          </button>
        </div>
      </a>

      <!-- Add item sub-row -->
      @if (expanded()) {
        <button class="space-child add-item-row" type="button"
          #addItemRef="nzPopover"
          nz-popover
          [nzPopoverContent]="createTpl"
          nzPopoverTrigger="click"
          nzPopoverPlacement="rightTop"
          nzPopoverOverlayClassName="sb-popover"
          (nzPopoverVisibleChange)="onOpen($event, addItemRef)"
          (click)="$event.stopPropagation()">
          <lucide-icon [img]="Plus" size="14"/><span>Add item</span>
        </button>
      }
    </div>

    <ng-template #contextTpl>
      <app-space-context-menu (itemClick)="closeMenus()" />
    </ng-template>

    <ng-template #createTpl>
      <app-create-menu
        (createList)="emit('createList')"
        (createFolder)="emit('createFolder')"
        (createSprint)="emit('createSprint')"
        (createDoc)="emit('createDoc')"
        (createDashboard)="emit('createDashboard')"
        (createWhiteboard)="emit('createWhiteboard')"
        (createForm)="emit('createForm')"
        (importItem)="emit('import')"
        (useTemplate)="emit('template')" />
    </ng-template>
  `,
  styles: [`
    :host { display: block; }

    .space-row-wrap { position: relative; overflow: visible; }
    .space-row {
      width: 100%; min-height: 2rem; display: flex; align-items: center; gap: .4rem;
      padding: 0 .4rem 0 .3rem; border: 0; border-radius: .35rem;
      color: var(--color-text-secondary); background: transparent;
      font: inherit; font-size: .75rem; font-weight: 520;
      text-align: start; text-decoration: none; cursor: pointer;
    }
    .space-row:hover, .space-row--selected { color: var(--color-text-primary); background: var(--color-surface-3); }
    .space-chevron {
      width: 1rem; height: 1rem; display: grid; place-items: center;
      border: 0; background: transparent; cursor: pointer;
      color: var(--color-text-muted); flex-shrink: 0; padding: 0;
    }
    .space-chevron:hover { color: var(--color-text-primary); }
    .space-name { flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .space-row-actions { display: none; align-items: center; gap: .1rem; margin-inline-start: auto; flex-shrink: 0; }
    .space-row:hover .space-row-actions,
    .space-row-wrap:hover .space-row .space-row-actions { display: flex; }
    .space-action-btn {
      width: 1.4rem; height: 1.4rem; display: grid; place-items: center;
      border: 0; border-radius: .28rem; background: transparent;
      color: var(--color-text-muted); cursor: pointer; padding: 0;
    }
    .space-action-btn:hover { background: var(--color-surface-2); color: var(--color-text-primary); }
    .space-badge {
      width: 1.2rem; height: 1.2rem; display: grid; place-items: center;
      border-radius: .28rem; color: #fff; background: var(--color-accent);
      font-size: .62rem; flex-shrink: 0;
    }
    .space-row__lock { flex: none; color: var(--color-text-muted); }
    .space-tooltip {
      position: absolute; top: -2rem; left: 0; z-index: 1000;
      padding: .28rem .6rem; background: #333; color: #fff;
      font-size: .68rem; border-radius: .3rem; white-space: nowrap;
      pointer-events: none; box-shadow: 0 2px 8px rgba(0,0,0,.35);
    }
    .space-tooltip::after {
      content: ''; position: absolute; top: 100%; left: 1rem;
      border: 5px solid transparent; border-top-color: #333;
    }
    .space-child {
      width: calc(100% - 1.2rem); min-height: 1.65rem; margin-inline-start: 1.2rem;
      display: flex; align-items: center; gap: .55rem; padding: 0 .55rem;
      border: 0; border-radius: .35rem; color: var(--color-text-muted);
      background: transparent; font: inherit; font-size: .68rem; cursor: pointer;
    }
    .space-child:hover { color: var(--color-text-primary); background: var(--color-surface-3); }
    .add-item-row { color: var(--color-text-muted); }
  `],
})
export class SpaceRowComponent {
  private readonly cdr = inject(ChangeDetectorRef);

  readonly space    = input.required<SidebarSpace>();
  readonly expanded = input(false);

  readonly expandToggle    = output<number>();
  readonly createListModal    = output<void>();
  readonly createFolderModal  = output<void>();
  readonly createSprintModal  = output<void>();
  readonly createDocModal     = output<void>();
  readonly createDashboard    = output<void>();
  readonly createWhiteboard   = output<void>();
  readonly createFormModal    = output<void>();
  readonly createFromImport   = output<void>();
  readonly createFromTemplate = output<void>();

  readonly ChevronRight   = ChevronRight;
  readonly ChevronDown    = ChevronDown;
  readonly Lock           = Lock;
  readonly MoreHorizontal = MoreHorizontal;
  readonly Plus           = Plus;

  readonly hovered = signal(false);

  /**
   * The currently open NzPopoverDirective instance.
   * We track it directly instead of using a string key because
   * we close via .hide() — not by flipping a signal binding.
   */
  private openDirective: NzPopoverDirective | null = null;

  /**
   * Called by (nzPopoverVisibleChange) on every trigger.
   *
   * WHY NO [nzPopoverVisible] BINDING:
   * When [nzPopoverVisible] is present, ng-zorro watches it for external changes.
   * On close, two things happen simultaneously:
   *   1. Our signal flips to false → Angular schedules a CD pass
   *   2. ng-zorro starts the CSS leave animation (ant-motion-zoom-big-leave)
   *   3. During that animation the CD pass fires, ng-zorro calls
   *      updatePosition() on the overlay — but the trigger element
   *      may already be re-rendering → ConnectedPositionStrategy returns
   *      {x:0, y:0} as a fallback → panel visually jumps to top-left,
   *      then the leave animation finishes from there.
   *
   * Solution: remove [nzPopoverVisible] entirely.
   * nzPopoverTrigger="click" already handles open/close for user interactions.
   * We only need to close PROGRAMMATICALLY (when a menu item is clicked),
   * and for that we call directive.hide() directly — which is a synchronous
   * CDK overlay detach, bypassing the animation scheduler entirely.
   */
  onOpen(visible: boolean, directive: NzPopoverDirective): void {
    if (visible) {
      // If another popover on this row was open, close it without animation first
      if (this.openDirective && this.openDirective !== directive) {
        this.openDirective.hide();
      }
      this.openDirective = directive;
    } else {
      // ng-zorro told us it closed (e.g. outside click) — record it
      if (this.openDirective === directive) {
        this.openDirective = null;
      }
    }
  }

  /**
   * Force-close whichever popover is open. Called from menu item handlers.
   * .hide() synchronously detaches the CDK OverlayRef — no leave animation,
   * no position recalculation, no jump.
   */
  closeMenus(): void {
    this.openDirective?.hide();
    this.openDirective = null;
    this.cdr.markForCheck();
  }

  emit(action: 'createList' | 'createFolder' | 'createSprint' | 'createDoc' |
               'createDashboard' | 'createWhiteboard' | 'createForm' | 'import' | 'template'): void {
    this.closeMenus();
    const map: Record<string, () => void> = {
      createList:       () => this.createListModal.emit(),
      createFolder:     () => this.createFolderModal.emit(),
      createSprint:     () => this.createSprintModal.emit(),
      createDoc:        () => this.createDocModal.emit(),
      createDashboard:  () => this.createDashboard.emit(),
      createWhiteboard: () => this.createWhiteboard.emit(),
      createForm:       () => this.createFormModal.emit(),
      import:           () => this.createFromImport.emit(),
      template:         () => this.createFromTemplate.emit(),
    };
    map[action]?.();
  }
}
