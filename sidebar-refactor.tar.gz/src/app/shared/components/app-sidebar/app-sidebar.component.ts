import {
  ChangeDetectionStrategy, Component, computed, effect, inject, input, output,
} from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';
import {
  LucideAngularModule,
  MoreHorizontal, PanelLeftClose, PanelLeftOpen, Plus, SlidersHorizontal,
} from 'lucide-angular';
import { SpaceStore }                    from '../../../core/stores/space.store';
import { SpaceService }                  from '../../../core/services/space.service';
import { WorkspaceStore }                from '../../../core/stores/workspace.store';
import { WorkspaceCustomizationService } from '../../../core/theme/workspace-customization.service';

import { AiChatsSectionComponent }      from './sub-components/ai-chats-section.component';
import { ChannelsSectionComponent }     from './sub-components/channels-section.component';
import { DirectMessagesSectionComponent } from './sub-components/direct-messages-section.component';
import { SpacesSectionComponent }       from './sub-components/spaces-section.component';

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [
    RouterLink, RouterLinkActive, LucideAngularModule,
    AiChatsSectionComponent,
    ChannelsSectionComponent,
    DirectMessagesSectionComponent,
    SpacesSectionComponent,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
  <aside class="context-sidebar" [class.context-sidebar--collapsed]="collapsed()">

    <!-- ── Top bar ── -->
    <div class="context-top">
      <strong>Home</strong>
      <div>
        <button type="button" aria-label="Filter your sidebar">
          <lucide-icon [img]="SlidersHorizontal" size="15"/>
        </button>
        <button type="button"
          [attr.aria-label]="collapsed() ? 'Open sidebar' : 'Close sidebar'"
          (click)="collapse.emit()">
          <lucide-icon [img]="collapsed() ? PanelLeftOpen : PanelLeftClose" size="16"/>
        </button>
        <button class="create" type="button" (click)="createRequested.emit()">
          <lucide-icon [img]="Plus" size="15"/>Create
        </button>
      </div>
    </div>

    <!-- ── Home nav ── -->
    <nav class="home-list">
      @for (item of checkedHomeItems(); track item.id) {
        <a class="context-nav__item" [routerLink]="item.route" routerLinkActive="context-nav__item--active">
          <lucide-icon [img]="item.icon" size="16"/><span>{{ item.label }}</span>
        </a>
      }
    </nav>
    <button class="more-link" type="button" (click)="more.emit()">
      <lucide-icon [img]="MoreHorizontal" size="16"/><span>More</span>
    </button>

    <!-- ── AI Chats ── -->
    <app-ai-chats-section />

    <!-- ── Spaces ── -->
    <app-spaces-section
      [spaces]="spaceStore.spaces()"
      [loading]="spaceStore.loading()"
      [error]="spaceStore.error()"
      [hasSpaces]="spaceStore.hasSpaces()"
      [workspaceName]="activeWorkspaceName()"
      (addSpace)="addSpace.emit()"
      (createListModal)="createListModal.emit()"
      (createFolderModal)="createFolderModal.emit()"
      (createSprintModal)="createSprintModal.emit()"
      (createDocModal)="createDocModal.emit()"
      (createDashboard)="createDashboard.emit()"
      (createWhiteboard)="createWhiteboard.emit()"
      (createFormModal)="createFormModal.emit()"
      (createFromImport)="createFromImport.emit()"
      (createFromTemplate)="createFromTemplate.emit()" />

    <!-- ── Channels ── -->
    <app-channels-section
      [workspaceName]="activeWorkspaceName()"
      (addChannel)="addChannel.emit()" />

    <!-- ── Direct Messages ── -->
    <app-direct-messages-section
      (newMessage)="newMessage.emit()" />

    <footer class="context-footer">
      <button type="button" (click)="settings.emit()">
        <lucide-icon [img]="SlidersHorizontal" size="15"/>Customize Sidebar
      </button>
    </footer>
  </aside>
  `,
  styles: [`
    :host { display: block; height: 100%; }

    .context-sidebar {
      position: relative; display: flex; flex-direction: column;
      width: 15.65rem; height: 100%; padding: .7rem .6rem;
      color: var(--color-text-secondary);
      background: var(--color-surface-1);
      border-inline-end: 1px solid var(--color-border);
      overflow: visible;
    }

    /* ── Top bar ── */
    .context-top { display: flex; align-items: center; justify-content: space-between; min-height: 2.2rem; padding-inline: .25rem; color: var(--color-text-primary); }
    .context-top strong { font-size: .96rem; }
    .context-top > div { display: flex; align-items: center; gap: .25rem; }
    .context-top button { width: 1.75rem; height: 1.75rem; display: grid; place-items: center; border: 0; border-radius: .35rem; color: var(--color-text-muted); background: transparent; cursor: pointer; padding: 0; }
    .context-top button:hover { color: var(--color-text-primary); background: var(--color-surface-3); }
    .context-top .create { width: auto; display: inline-flex; gap: .25rem; padding: 0 .55rem; color: #fff; background: var(--color-accent); font: inherit; font-size: .73rem; font-weight: 750; }
    .context-top .create:hover { background: var(--color-accent-strong); }

    /* ── Home nav ── */
    .home-list { display: grid; gap: .05rem; margin-top: .2rem; }
    .more-link { width: 100%; min-height: 1.8rem; display: flex; align-items: center; gap: .5rem; margin-top: .15rem; padding: 0 .55rem; border: 0; border-radius: .35rem; color: var(--color-text-muted); background: transparent; font: inherit; font-size: .72rem; cursor: pointer; }
    .more-link:hover { color: var(--color-text-primary); background: var(--color-surface-3); }

    .context-nav__item {
      width: 100%; min-height: 1.9rem; display: flex; align-items: center; gap: .55rem;
      padding: 0 .55rem; border: 0; border-radius: .35rem;
      color: var(--color-text-secondary); background: transparent;
      font: inherit; font-size: .75rem; font-weight: 520; text-align: start; text-decoration: none; cursor: pointer;
    }
    .context-nav__item:hover { color: var(--color-text-primary); background: var(--color-surface-3); }
    .context-nav__item--active { color: var(--color-text-primary); background: var(--color-surface-3); }

    /* ── Footer ── */
    .context-footer { margin-top: auto; padding-top: .5rem; border-top: 1px solid var(--color-border); }
    .context-footer button { width: 100%; min-height: 1.9rem; display: flex; align-items: center; gap: .5rem; border: 0; border-radius: .35rem; padding: 0 .55rem; color: var(--color-text-secondary); background: transparent; font: inherit; font-size: .72rem; cursor: pointer; }
    .context-footer button:hover { color: var(--color-text-primary); background: var(--color-surface-3); }

    /* ── Collapsed state ── */
    .context-sidebar--collapsed { width: 4.3rem; }
    .context-sidebar--collapsed .context-top strong,
    .context-sidebar--collapsed .create span,
    .context-sidebar--collapsed .more-link span,
    .context-sidebar--collapsed .home-list,
    .context-sidebar--collapsed .context-nav__item span,
    .context-sidebar--collapsed app-ai-chats-section,
    .context-sidebar--collapsed app-spaces-section,
    .context-sidebar--collapsed app-channels-section,
    .context-sidebar--collapsed app-direct-messages-section,
    .context-sidebar--collapsed .context-footer button span { display: none; }
    .context-sidebar--collapsed .context-top { justify-content: center; }
    .context-sidebar--collapsed .context-top > div { flex-direction: column; }
    .context-sidebar--collapsed .create { width: 2.1rem; padding: 0; }

    @media (max-width: 720px) { .context-sidebar { display: none; } }

    /* ── Popover panel overrides (global, CDK overlay is appended to body) ── */
    ::ng-deep .sb-popover .ant-popover-arrow,
    ::ng-deep .sb-popover .ant-popover-arrow-content { display: none !important; }
    ::ng-deep .sb-popover .ant-popover-inner-content { padding: 0 !important; }
    ::ng-deep .sb-popover .ant-popover-inner {
      padding: 0 !important;
      background: var(--color-surface-1) !important;
      border: 1px solid var(--color-border) !important;
      border-radius: .5rem !important;
      box-shadow: 0 8px 24px rgba(0, 0, 0, .45) !important;
      overflow: visible !important;
    }
  `],
})
export class AppSidebarComponent {
  readonly SlidersHorizontal = SlidersHorizontal;
  readonly PanelLeftClose    = PanelLeftClose;
  readonly PanelLeftOpen     = PanelLeftOpen;
  readonly Plus              = Plus;
  readonly MoreHorizontal    = MoreHorizontal;

  private readonly workspace    = inject(WorkspaceCustomizationService);
  private readonly spaceService = inject(SpaceService);
  readonly workspaceStore       = inject(WorkspaceStore);
  readonly spaceStore           = inject(SpaceStore);

  constructor() {
    effect(() => {
      const workspaceId = this.workspaceStore.activeWorkspace()?.id;
      if (workspaceId != null) {
        this.spaceService.loadSpacesByWorkspace(workspaceId).subscribe({ error: () => {} });
      }
    });
  }

  readonly checkedHomeItems    = computed(() => this.workspace.homeItems().filter(i => i.checked));
  readonly activeWorkspaceName = computed(() => this.workspaceStore.activeWorkspace()?.name ?? '');

  // ── Inputs / Outputs ────────────────────────────────────────────────────────
  readonly collapsed       = input(false);
  readonly collapse        = output<void>();
  readonly settings        = output<void>();
  readonly more            = output<void>();
  readonly createRequested = output<void>();
  readonly addSpace        = output<void>();
  readonly addSpaceItem    = output<void>();
  readonly addChannel      = output<void>();
  readonly newMessage      = output<void>();

  // Create modal outputs (forwarded from SpacesSectionComponent → SpaceRowComponent)
  readonly createListModal    = output<void>();
  readonly createFolderModal  = output<void>();
  readonly createSprintModal  = output<void>();
  readonly createDocModal     = output<void>();
  readonly createDashboard    = output<void>();
  readonly createWhiteboard   = output<void>();
  readonly createFormModal    = output<void>();
  readonly createFromImport   = output<void>();
  readonly createFromTemplate = output<void>();
}
