import { ChangeDetectionStrategy, Component, input, output } from '@angular/core';
import { RouterLink } from '@angular/router';
import { LucideAngularModule, Hash, Plus } from 'lucide-angular';

@Component({
  selector: 'app-channels-section',
  standalone: true,
  imports: [RouterLink, LucideAngularModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <section class="nav-section channels">
      <p>CHANNELS</p>
      <a class="context-nav__item" routerLink="/channels/welcome">
        <lucide-icon [img]="Hash" size="16"/><span>Welcome</span>
      </a>
      <a class="context-nav__item" routerLink="/channels/general">
        <b class="channel-dot">f</b>
        <span>General <em>· {{ workspaceName() }}</em></span>
      </a>
      <button class="context-nav__item context-nav__item--muted" type="button" (click)="addChannel.emit()">
        <lucide-icon [img]="Plus" size="16"/><span>Add Channel</span>
      </button>
    </section>
  `,
  styles: [`
    :host { display: block; }
    .nav-section { margin: .55rem 0; }
    .nav-section p { margin: 0 0 .35rem .55rem; color: var(--color-text-muted); font-size: .61rem; font-weight: 800; letter-spacing: .08em; }
    .context-nav__item {
      width: 100%; min-height: 1.9rem; display: flex; align-items: center; gap: .55rem;
      padding: 0 .55rem; border: 0; border-radius: .35rem;
      color: var(--color-text-secondary); background: transparent;
      font: inherit; font-size: .75rem; font-weight: 520; text-align: start; text-decoration: none; cursor: pointer;
    }
    .context-nav__item:hover { color: var(--color-text-primary); background: var(--color-surface-3); }
    .context-nav__item em { color: var(--color-text-muted); font-size: .65rem; font-style: normal; }
    .context-nav__item--muted { color: var(--color-text-muted); }
    .channel-dot { width: 1rem; height: 1rem; display: grid; place-items: center; border-radius: 50%; color: #fff; background: #16a883; font-size: .59rem; }
  `],
})
export class ChannelsSectionComponent {
  readonly Hash = Hash;
  readonly Plus = Plus;

  readonly workspaceName = input('');
  readonly addChannel = output<void>();
}
