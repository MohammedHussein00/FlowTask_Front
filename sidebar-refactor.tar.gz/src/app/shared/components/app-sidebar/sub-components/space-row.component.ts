import {
  ChangeDetectionStrategy, ChangeDetectorRef, Component, inject,
  input, output, signal,
} from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';
import {
  LucideAngularModule,
  ChevronRight, ChevronDown, Lock, MoreHorizontal, Plus,
} from 'lucide-angular';
import { NzPopoverModule, NzPopoverDirective } from 'ng-zorro-antd/popover';
import { SpaceContextMenuComponent } from '../popovers/space-context-menu.component';
import { CreateMenuComponent } from '../popovers/create-menu.component';

export interface SidebarSpace {
  id: number;
  name: string;
  color: string;
  isPrivate?: boolean;
}

@Component({
  selector: 'app-space-row',
  standalone: true,
  imports: [
    RouterLink, RouterLinkActive, LucideAngularModule,
    NzPopoverModule, SpaceContextMenuComponent, CreateMenuComponent,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-row-wrap"
      (mouseenter)="hovered.set(true)"
      (mouseleave)="hovered.set(false)">

      @if (hovered()) {
        <div class="space-tooltip">Create Folders, Lists, Docs and more</div>
      }

      <a class="space-row" routerLink="/all-spaces" routerLinkActive="space-row--selected">
        <button class="space-chevron" type="button"
          (click)="$event.preventDefault(); expandToggle.emit(space().id)">
          <lucide-icon [img]="expanded() ? ChevronDown : ChevronRight" size="12"/>
        </button>
        <b class="space-badge" [style.background]="space().color">
          {{ space().name.charAt(0).toUpperCase() }}
        </b>
        <span class="space-name">{{ space().name }}</span>
        @if (space().isPrivate) {
          <lucide-icon [img]="Lock" size="12" class="space-row__lock"/>
        }

        <div class="space-row-actions">
          <!-- ··· 3-dots context menu ··· -->
          <button class="space-action-btn" type="button"
            #contextPopover="nzPopover"
            nz-popover
            [nzPopoverContent]="contextTpl"
            nzPopoverTrigger="click"
            [nzPopoverVisible]="activeKey() === 'context'"
            (nzPopoverVisibleChange)="onVisibleChange($event, 'context', contextPopover)"
            nzPopoverPlacement="rightTop"
            nzPopoverOverlayClassName="sb-popover"
            (click)="$event.preventDefault(); $event.stopPropagation()">
            <lucide-icon [img]="MoreHorizontal" size="14"/>
          </button>

          <!-- ··· + create ··· -->
          <button class="space-action-btn" type="button"
            #createPopover="nzPopover"
            nz-popover
            [nzPopoverContent]="createTpl"
            nzPopoverTrigger="click"
            [nzPopoverVisible]="activeKey() === 'create'"
            (nzPopoverVisibleChange)="onVisibleChange($event, 'create', createPopover)"
            nzPopoverPlacement="rightTop"
            nzPopoverOverlayClassName="sb-popover"
            (click)="$event.preventDefault(); $event.stopPropagation()">
            <lucide-icon [img]="Plus" size="14"/>
          </button>
        </div>
      </a>

      <!-- Add item sub-row (shown when expanded) -->
      @if (expanded()) {
        <button class="space-child add-item-row" type="button"
          #addItemPopover="nzPopover"
          nz-popover
          [nzPopoverContent]="createTpl"
          nzPopoverTrigger="click"
          [nzPopoverVisible]="activeKey() === 'additem'"
          (nzPopoverVisibleChange)="onVisibleChange($event, 'additem', addItemPopover)"
          nzPopoverPlacement="rightTop"
          nzPopoverOverlayClassName="sb-popover"
          (click)="$event.stopPropagation()">
          <lucide-icon [img]="Plus" size="14"/><span>Add item</span>
        </button>
      }
    </div>

    <!-- Popover content templates -->
    <ng-template #contextTpl>
      <app-space-context-menu (itemClick)="closeMenus()" />
    </ng-template>

    <ng-template #createTpl>
      <app-create-menu
        (createList)="emit('createList')"
        (createFolder)="emit('createFolder')"
        (createSprint)="emit('createSprint')"
        (createDoc)="emit('createDoc')"
        (createDashboard)="emit('createDashboard')"
        (createWhiteboard)="emit('createWhiteboard')"
        (createForm)="emit('createForm')"
        (importItem)="emit('import')"
        (useTemplate)="emit('template')" />
    </ng-template>
  `,
  styles: [`
    :host { display: block; }

    .space-row-wrap { position: relative; overflow: visible; }
    .space-row {
      width: 100%; min-height: 2rem; display: flex; align-items: center; gap: .4rem;
      padding: 0 .4rem 0 .3rem; border: 0; border-radius: .35rem;
      color: var(--color-text-secondary); background: transparent;
      font: inherit; font-size: .75rem; font-weight: 520;
      text-align: start; text-decoration: none; cursor: pointer;
    }
    .space-row:hover, .space-row--selected { color: var(--color-text-primary); background: var(--color-surface-3); }
    .space-chevron {
      width: 1rem; height: 1rem; display: grid; place-items: center;
      border: 0; background: transparent; cursor: pointer;
      color: var(--color-text-muted); flex-shrink: 0; padding: 0;
    }
    .space-chevron:hover { color: var(--color-text-primary); }
    .space-name { flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .space-row-actions { display: none; align-items: center; gap: .1rem; margin-inline-start: auto; flex-shrink: 0; }
    .space-row:hover .space-row-actions,
    .space-row-wrap:hover .space-row .space-row-actions { display: flex; }
    .space-action-btn {
      width: 1.4rem; height: 1.4rem; display: grid; place-items: center;
      border: 0; border-radius: .28rem; background: transparent;
      color: var(--color-text-muted); cursor: pointer; padding: 0;
    }
    .space-action-btn:hover { background: var(--color-surface-2); color: var(--color-text-primary); }
    .space-badge {
      width: 1.2rem; height: 1.2rem; display: grid; place-items: center;
      border-radius: .28rem; color: #fff; background: var(--color-accent);
      font-size: .62rem; flex-shrink: 0;
    }
    .space-row__lock { flex: none; color: var(--color-text-muted); }
    .space-tooltip {
      position: absolute; top: -2rem; left: 0; z-index: 1000;
      padding: .28rem .6rem; background: #333; color: #fff;
      font-size: .68rem; border-radius: .3rem; white-space: nowrap;
      pointer-events: none; box-shadow: 0 2px 8px rgba(0,0,0,.35);
    }
    .space-tooltip::after {
      content: ''; position: absolute; top: 100%; left: 1rem;
      border: 5px solid transparent; border-top-color: #333;
    }
    .space-child {
      width: calc(100% - 1.2rem); min-height: 1.65rem; margin-inline-start: 1.2rem;
      display: flex; align-items: center; gap: .55rem; padding: 0 .55rem;
      border: 0; border-radius: .35rem; color: var(--color-text-muted);
      background: transparent; font: inherit; font-size: .68rem; cursor: pointer;
    }
    .space-child:hover { color: var(--color-text-primary); background: var(--color-surface-3); }
    .add-item-row { color: var(--color-text-muted); }
  `],
})
export class SpaceRowComponent {
  private readonly cdr = inject(ChangeDetectorRef);

  readonly space    = input.required<SidebarSpace>();
  readonly expanded = input(false);

  readonly expandToggle    = output<number>();
  readonly createListModal    = output<void>();
  readonly createFolderModal  = output<void>();
  readonly createSprintModal  = output<void>();
  readonly createDocModal     = output<void>();
  readonly createDashboard    = output<void>();
  readonly createWhiteboard   = output<void>();
  readonly createFormModal    = output<void>();
  readonly createFromImport   = output<void>();
  readonly createFromTemplate = output<void>();

  readonly ChevronRight = ChevronRight;
  readonly ChevronDown  = ChevronDown;
  readonly Lock         = Lock;
  readonly MoreHorizontal = MoreHorizontal;
  readonly Plus         = Plus;

  readonly hovered   = signal(false);
  /**
   * Which of this row's popovers is currently open: 'context' | 'create' | 'additem' | null.
   * Keeping this per-row (rather than a global key in the parent) means each row
   * manages its own open state and we never need to match string keys across rows.
   */
  readonly activeKey = signal<'context' | 'create' | 'additem' | null>(null);

  /** Track the currently-open NzPopoverDirective so we can call .hide() on it directly. */
  private openDirective: NzPopoverDirective | null = null;

  /**
   * Called by (nzPopoverVisibleChange) on every trigger button.
   *
   * The popover close bug (disappear → jump to left → disappear with animation)
   * is caused by:
   *   1. Setting [nzPopoverVisible] = false — ng-zorro starts a CSS leave animation.
   *   2. Before the animation completes, change detection re-runs and the overlay
   *      loses its position anchor, so it snaps to [0, 0] (top-left of the viewport)
   *      then fades out from there.
   *
   * Fix: instead of flipping the signal (which triggers the broken animation path),
   * call NzPopoverDirective.hide() **directly** on the directive instance.  That
   * synchronously detaches the CDK overlay without going through the leave-animation
   * scheduler, so there is no frame where the panel is unanchored.
   */
  onVisibleChange(
    visible: boolean,
    key: 'context' | 'create' | 'additem',
    directive: NzPopoverDirective,
  ): void {
    if (visible) {
      // A different key is opening — force-close whatever was open first.
      if (this.openDirective && this.openDirective !== directive) {
        this.openDirective.hide();
      }
      this.activeKey.set(key);
      this.openDirective = directive;
    } else {
      // ng-zorro fired visibleChange=false (e.g. backdrop click).
      // Call hide() synchronously to skip the buggy animation path.
      directive.hide();
      this.activeKey.set(null);
      this.openDirective = null;
      this.cdr.markForCheck();
    }
  }

  /** Force-close all popovers on this row without animation. */
  closeMenus(): void {
    this.openDirective?.hide();
    this.activeKey.set(null);
    this.openDirective = null;
    this.cdr.markForCheck();
  }

  /** Dispatch the right output then close. */
  emit(action: 'createList' | 'createFolder' | 'createSprint' | 'createDoc' |
               'createDashboard' | 'createWhiteboard' | 'createForm' | 'import' | 'template'): void {
    this.closeMenus();
    const map: Record<string, () => void> = {
      createList:      () => this.createListModal.emit(),
      createFolder:    () => this.createFolderModal.emit(),
      createSprint:    () => this.createSprintModal.emit(),
      createDoc:       () => this.createDocModal.emit(),
      createDashboard: () => this.createDashboard.emit(),
      createWhiteboard:() => this.createWhiteboard.emit(),
      createForm:      () => this.createFormModal.emit(),
      import:          () => this.createFromImport.emit(),
      template:        () => this.createFromTemplate.emit(),
    };
    map[action]?.();
  }
}
